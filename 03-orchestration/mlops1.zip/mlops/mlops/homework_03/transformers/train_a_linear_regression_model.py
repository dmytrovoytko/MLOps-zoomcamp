from sklearn.feature_extraction import DictVectorizer
from sklearn.linear_model import LinearRegression
from sklearn.linear_model import Lasso
from sklearn.linear_model import Ridge

from sklearn.metrics import mean_squared_error, root_mean_squared_error

import mlflow

if 'transformer' not in globals():
    from mage_ai.data_preparation.decorators import transformer
if 'test' not in globals():
    from mage_ai.data_preparation.decorators import test


@transformer
def traine_lin_reg_model(df, *args, **kwargs):

    categorical = ['PULocationID', 'DOLocationID']
    numerical = ['trip_distance']

    mlflow.set_tracking_uri('sqlite:///mlflow/mlflow.db')
    mlflow.set_experiment('nyc-taxi-hw3')
    mlflow.autolog()

    with mlflow.start_run():
        mlflow.set_tag("model", "lr")
        # mlflow.log_params(params)

        # train_dicts = df[categorical + numerical].to_dict(orient='records')
        train_dicts = df[categorical].to_dict(orient='records')
        print('->> dv.fit_transform')
        dv = DictVectorizer()
        X_train = dv.fit_transform(train_dicts)

        target = 'duration'
        y_train = df[target].values

        print('->> lr.fit')
        lr = LinearRegression()
        lr.fit(X_train, y_train)

        print('->> lr.predict')
        y_pred = lr.predict(X_train)

        # mean_squared_error(y_train, y_pred, squared=False)
        rmse = root_mean_squared_error(y_train, y_pred)    

        mlflow.log_metric("rmse", rmse)

    print('rmse', rmse)
    print('intercept_', lr.intercept_)

    return dv, lr, rmse


@test
def test_output(output, *args) -> None:
    """
    Template code for testing the output of the block.
    """
    assert output is not None, 'The output is undefined'