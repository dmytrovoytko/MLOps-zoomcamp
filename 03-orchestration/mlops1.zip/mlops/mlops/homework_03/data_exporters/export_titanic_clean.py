from mage_ai.io.file import FileIO
from pandas import DataFrame

import mlflow
from sklearn.feature_extraction import DictVectorizer
from sklearn.linear_model import LinearRegression
from sklearn.linear_model import Lasso
from sklearn.linear_model import Ridge

from sklearn.metrics import root_mean_squared_error

if 'data_exporter' not in globals():
    from mage_ai.data_preparation.decorators import data_exporter


# @data_exporter
def export_data_to_file(df: DataFrame, **kwargs) -> None:
    """
    Template for exporting data to filesystem.

    Docs: https://docs.mage.ai/design/data-loading#example-loading-data-from-a-file
    """
    filepath = 'yellow_trips_prepared.csv'
    FileIO().export(df, filepath)

@data_exporter
def export_model_artidacts(dv, model, rmse, **kwargs) -> None:
    mlflow.autolog()

    with mlflow.start_run():
        mlflow.set_tag("model", "lr")
        # mlflow.log_params(params)
        mlflow.log_metric("rmse", rmse)
        # test_rmse = root_mean_squared_error(y_test, rf.predict(X_test))
        # mlflow.log_metric("test_rmse", test_rmse)
        
