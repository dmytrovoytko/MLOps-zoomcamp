# Dynamic blocks

A dynamic block will create multiple downstream blocks at runtime.

The number of blocks it creates is equal to the number of items in the output data of the dynamic block multiplied by the number of its downstream blocks.

Read more about it [here](https://docs.mage.ai/design/blocks/dynamic-blocks).